<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CrudController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::get('/service', [CrudController::class, 'index'])->name('service.all');
Route::post('/service', [CrudController::class, 'store'])->name('service.store');
Route::post('/service/update/{id}', [CrudController::class, 'update'])->name('service.update');
// Route::get('/service/{id}', [CrudController::class, 'show'])->name('service.show');
Route::get('/service/edit/{id}', [CrudController::class, 'edit'])->name('service.edit');
Route::delete('/service/delete/{id}', [CrudController::class, 'destroy'])->name('service.destroy');
